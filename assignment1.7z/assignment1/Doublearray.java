package seleniumclass;
import java.util.Scanner;

public class Doublearray {
	public static void main(String[] args){
		double[][] a=new double[2][2];
		/*a[0][0]=1;
		a[0][1]=2;
	    a[1][0]=3;
	    a[1][1]=4;*/
		Scanner obj= new Scanner(System.in);
		
		
	    for(int r=0;r<a.length;r++){
	    	System.out.println("enter "+(r+1) + "row values");
	    	for(int c=0;c<a.length;c++){
	    		System.out.println("enter "+ (1+c)+"column values");
	    		a[r][c]= obj.nextDouble();
	    	}
	    	 }
	    
	    System.out.println("given array values are:");
	    for(int r=0;r<a.length;r++){
	    	for (int c=0;c<a.length;c++){
	    		System.out.print(a[r][c]+"     ");
	    		System.out.print(" *  ");
	    	}
	    	System.out.println("&\t");
	    }
	    
	   /* System.out.println("array values are:"+a[0][0]);
	    System.out.println("array values are:"+a[0][1]);
	    System.out.println("array values are:"+a[1][0]);
	    System.out.println("array values are:"+a[1][1]);*/
	}

}
