package seleniumclass;

public class Rarea {
	public static double[] crarea(){
		
		double l,h,ar;
		l=5;
		h=10;
		ar=l*h;
		double r=10,ac;
		ac=3.14*r*r;
		double[] area= new double[2];
		area[0]=ac;
		area[1]=ar;
		return area;
		
		
	}
	public static void main(String[] args){
		Rarea obj=new Rarea();
		double[] r= obj.crarea();
		System.out.println(" circle areas are:"+r[0]);
		System.out.println("rectangle areas are:"+r[1]);
		
		
		
	}

}
