package seleniumclass;
import java.util.Scanner;
import java.io.*;


public class Arrays {
	public static void main(String[] args) throws IOExceptions, NumberFormatException, IOException{
		System.out.println("enter array values:");
		int [] a= new int[5];
		InputStreamReader obj= new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader (obj);
		
		//Scanner obj= new Scanner(System.in);
		for(int i=0;i<a.length;i++){
			a[i]=Integer.parseInt( br.readLine());
			
		}
		for(int x=0;x<a.length;x++)
System.out.println("array vlues:"+a[x]);
		
	}

}
