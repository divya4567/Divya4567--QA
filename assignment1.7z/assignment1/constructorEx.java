package seleniumclass;

public class constructorEx {
	
	int eno;
	String ename;
	double salary;
	//default constructor
public constructorEx(){
	eno=1;
	ename="divya";
	 salary=8000;
		
	}
	//argument constructor
	public constructorEx(int x,String s,double d){
		 eno=x;
		ename=s;
		 salary=d;	
	}
	
	//copy constructor
	public constructorEx(constructorEx obj){
		 eno=obj.eno;
			ename=obj.ename;
			 salary=obj.salary;
	}
	
	public void display(){
		System.out.println("employee details:");
		System.out.println(".................");
		System.out.println("employee name:"+ename);
		System.out.println("eno:"+eno);
		System.out.println("esalary:"+salary);
		
	}
	public static void main(String[] args){
		constructorEx obj1=new constructorEx();
		constructorEx obj2=new constructorEx(2,"bunny",10000);
		constructorEx obj3=new constructorEx(obj2);
		
		//obj.Defaultconstructor();
		obj1.display();
		obj2.display();
		obj3.display();
	}
}