

import static org.junit.Assert.*;

import org.junit.Test;

import com.lamar.CS.StringHelper;

public class StringHelperTest {

	@Test
	public void test_Ainfirst2positions() {
		StringHelper helper=new StringHelper();
		String expected= "CD";
		String Actual= helper.truncateAInFirst2Positions("AACD");
		
	assertEquals(expected,Actual);
		
			}

	@Test
	public void test2_Ainfirstposition(){	
		StringHelper helper=new StringHelper();
		
		String expected= "CD";
		String Actual= helper.truncateAInFirst2Positions("ACD");
		
		assertEquals(expected,Actual);
		
	}
	
	@Test
	public void test3_Aisnotintheinput(){
		
		StringHelper helper=new StringHelper();
		String Actual= helper.truncateAInFirst2Positions("CDEF");
		
		String expected= "CDEF";
		
		
		assertEquals(expected,Actual);
	}
		@Test
		public void test4_Aisislastpositions(){
			StringHelper helper= new  StringHelper();
			String Actual= helper.truncateAInFirst2Positions("CDAA");
			String Expected= "CDAA";
			assertEquals(Expected, Actual);
			
			
		}
		
		
		
	}

	
	
	//org.junit.ComparisonFailure: expected:<ABC[]> but was:<ABC[D]>
	
	

